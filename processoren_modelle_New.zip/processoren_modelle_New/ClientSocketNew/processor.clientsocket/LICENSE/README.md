## AsTeRICS licensing

**This folder is used to reflect the used licenses for this component.**

**A contributor must add the respective license file** for the component (either **LICENSE_MITOrGPLv3WithException.txt** or one of the two dual license options) to the component/LICENSE folder. Furthermore, **for each thirdparty library** used, the license file must be added with the following naming convention (Please use CamelCase notation for the library and license names):

THIRDPARTY_NameOfLibrary_LicenseNameInclVersionInfo.txt